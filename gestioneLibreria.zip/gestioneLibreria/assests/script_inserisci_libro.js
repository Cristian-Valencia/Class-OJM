function inserisciLibro(){

    var varIsbn = document.getElementById("isbn").value ;
    var varTitolo = document.getElementById("bookTitle").value ;
    var varAutore = document.getElementById("bookAuthor").value ;
    var varCodice = document.getElementById("selectCat").value ;

    var objLibro = {
        isbn: varIsbn,
        titolo: varTitolo,
        autore : varAutore,
        categoria_rif : varCodice
    };

    // console.log(objLibro);
    //console.log(JSON.stringify(objProdotto));


    $.ajax(
        {
            url: "http://localhost:8082/libro/inserisciLibro",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(objLibro),
            dataType: "json",
            success: function(risultato){
                alert("Inserimento effettuato con successo!")
                // aggiornaElenco();
            },
            error: function(errore){
                alert("Errore di esecuzione")
                console.log(errore);
            }
        }
    )
}

function elencoCategorie(){
    $.ajax(
        {
            url: "http://localhost:8082/categoria/",
            type: "GET",
            success: function(risultato){
                elencoCat = risultato;
                console.log(elencoCat) ;
                selectCategorie() ;
            },
            error: function(errore){
                console.log(errore)
            }
        }
    )


}

function selectCategorie(){

    var stringaHtml = "";

    for(var i=0; i<elencoCat.length; i++){
        var temp = elencoCat[i];

        stringaHtml += `
            
            <option value="${temp.id_categoria}">${temp.titolo}</option>

        `
    }

    document.getElementById("selectCat").innerHTML = stringaHtml;

}

elencoCategorie() ;


var elencoCat = [] ;