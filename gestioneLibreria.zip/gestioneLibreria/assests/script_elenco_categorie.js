function stampaProdotti(arrayDaStampare){
    var stringaHtml = "";

    for(var i=0; i<arrayDaStampare.length; i++){
        var temp = arrayDaStampare[i];

        stringaHtml += "<tr>";
        stringaHtml +=      "<td>" + temp.id_categoria + "</td>";
        stringaHtml +=      "<td>" + temp.titolo + "</td>";
        stringaHtml +=      "<td>" + temp.codice_categoria + "</td>";
        stringaHtml +=      "<td>";
        stringaHtml +=      "   <button type=\"button\" class=\"btn btn-danger\" onclick=\"eliminaCategoria(" + temp.id_categoria + ")\">";
        stringaHtml +=      "       <i class=\"fas fa-trash-alt\"></i>";
        stringaHtml +=      "   </button>";
        stringaHtml +=      "   <button type=\"button\" class=\"btn btn-warning\" onclick=\"modificaCategoria(" + temp.id_categoria + ")\">";
        stringaHtml +=      "       <i class=\"fas fa-edit\"></i>";
        stringaHtml +=      "   </button>";
        stringaHtml +=      "</td>";
        stringaHtml += "</tr>";
    }

    document.getElementById("contenuto-tabella").innerHTML = stringaHtml;
    
}

function eliminaCategoria(varIdentificatore){

    //Il BackTick si fa con Alt + 96 della tastiera numerica!

    $.ajax(
        {
            //url: "http://localhost:8082/prodotto/" + varIdentificatore,
            url: `http://localhost:8082/categoria/${varIdentificatore}`,
            type: "DELETE",
            success: function(risultato){
                alert("Eliminazione effettuata con success");
                aggiornaElenco();
            },
            error: function(errore){
                alert("Ops... qualcosa è andato storto ;(");
                console.log(errore);
            }
        }
    )

}

function modificaCategoria(varIdentificatore){
    for(var i=0; i<elencoCategorie.length; i++){
        var temp = elencoCategorie[i];

        if(temp.id_categoria == varIdentificatore){
            document.getElementById("varModId").value = temp.id_categoria;
            document.getElementById("varModNome").value = temp.titolo;
            document.getElementById("varModCodice").value = temp.codice_categoria;
        }
    }

    $("#modaleModifica").modal('show');
}

function effettuaModifica(){


    var varModId = document.getElementById("varModId").value;


    var varModNome = document.getElementById("varModNome").value;
    var varModCodice = document.getElementById("varModCodice").value;

    var objCategoria = {
        id_categoria: varModId,
        titolo: varModNome,
        codice_categoria: varModCodice
    }

    console.log(objCategoria) ;

    $.ajax(
        {
            url: "http://localhost:8082/categoria/update",
            type: "PUT",
            contentType: "application/json",
            data: JSON.stringify(objCategoria),
            dataType: 'json',
            success: function(risultato){
                alert("Modifica effettuata con successo");
                
                aggiornaElenco();

                document.getElementById("varModId").value = "";
                document.getElementById("varModNome").value = "";
                document.getElementById("varModCodice").value = "";
            
                $("#modaleModifica").modal('hide');
            },
            error: function(errore){
                alert("Ops... non ho modificato nulla ;(");
            }
        }
    )
}

function aggiornaElenco(){
    $.ajax(
        {
            url: "http://localhost:8082/categoria/",
            type: "GET",
            success: function(risultato){
                console.log(risultato)
                elencoCategorie = risultato;
                stampaProdotti(elencoCategorie);
            },
            error: function(errore){
                console.log(errore)
            }
        }
    )
}

var contatore = 0;
var elencoCategorie = [];

aggiornaElenco();