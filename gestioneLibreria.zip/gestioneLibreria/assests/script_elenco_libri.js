function stampaLibri(arrayDaStampare){
    var stringaHtml = "";

    for(var i=0; i<arrayDaStampare.length; i++){
        var temp = arrayDaStampare[i];

        stringaHtml += "<tr>";
        stringaHtml +=      "<td>" + temp.id_libro + "</td>";
        stringaHtml +=      "<td>" + temp.isbn + "</td>";
        stringaHtml +=      "<td>" + temp.titolo + "</td>";
        stringaHtml +=      "<td>" + temp.autore + "</td>";
        stringaHtml +=      "<td>" + temp.categoria_rif + "</td>";
        stringaHtml +=      "<td>";
        stringaHtml +=      "   <button type=\"button\" class=\"btn btn-danger\" onclick=\"eliminaLibro(" + temp.id_libro + ")\">";
        stringaHtml +=      "       <i class=\"fas fa-trash-alt\"></i>";
        stringaHtml +=      "   </button>";
        stringaHtml +=      "   <button type=\"button\" class=\"btn btn-warning\" onclick=\"modificaLibro(" + temp.id_libro + ")\">";
        stringaHtml +=      "       <i class=\"fas fa-edit\"></i>";
        stringaHtml +=      "   </button>";
        stringaHtml +=      "</td>";
        stringaHtml += "</tr>";
    }

    document.getElementById("contenuto-tabella").innerHTML = stringaHtml;
}

function eliminaLibro(varIdentificatore){

    $.ajax(
        {
            //url: "http://localhost:8082/prodotto/" + varIdentificatore,
            url: `http://localhost:8082/libro/${varIdentificatore}`,
            type: "DELETE",
            success: function(risultato){
                alert("Eliminazione effettuata con success");
                aggiornaElenco();
            },
            error: function(errore){
                alert("Ops... qualcosa è andato storto ;(");
                console.log(errore);
            }
        }
    )

}

function modificaLibro(varIdentificatore){

    for(var i=0; i<elencoLibri.length; i++){
        var temp = elencoLibri[i];

        if(temp.id_libro == varIdentificatore){
            document.getElementById("varModId").value = temp.id_libro;
            document.getElementById("varModIsbn").value = temp.isbn;
            document.getElementById("varModTitolo").value = temp.titolo;
            document.getElementById("varModAutore").value = temp.autore;
            document.getElementById("varModCodice").value = temp.categoria_rif;
        }
    }

    $("#modaleModifica").modal('show');

}

function effettuaModifica(){

    var varModId = document.getElementById("varModId").value ;
    var varModIsbn = document.getElementById("varModIsbn").value ;
    var varModTitolo = document.getElementById("varModTitolo").value ;
    var varModAutore = document.getElementById("varModAutore").value ;
    var varModCategoriaRif = document.getElementById("varModCodice").value ;

    var objLibro = {
        id_libro : varModId,
        isbn : varModIsbn,
        titolo: varModTitolo,
        autore : varModAutore,
        categoria_rif : varModCategoriaRif 
    }

    console.log(objLibro) ;

    $.ajax(
        {
            url: "http://localhost:8082/libro/updateBook",
            type: "PUT",
            contentType: "application/json",
            data: JSON.stringify(objLibro),
            dataType: 'json',
            success: function(risultato){

                alert("Modifica effettuata con successo");
                
                aggiornaElenco();

                document.getElementById("varModId").value = "";
                document.getElementById("varModIsbn").value = "";
                document.getElementById("varModTitolo").value = "";
                document.getElementById("varModAutore").value = "";
                document.getElementById("varModCodice").value = "";
            
                $("#modaleModifica").modal('hide');
            },
            error: function(errore){
                alert("Ops... non ho modificato nulla ;(");
            }
        }
    )
}

function aggiornaElenco(){
    $.ajax(
        {
            url: "http://localhost:8082/libro/",
            type: "GET",
            success: function(risultato){
                console.log(risultato)
                elencoLibri = risultato;
                stampaLibri(elencoLibri);
            },
            error: function(errore){
                console.log(errore)
            }
        }
    )
}

var contatore = 0;
var elencoLibri = [];

aggiornaElenco();