// console.log(" siamo nella pagina inserisci Categoria !!!")

function inserisciCategoria(){

    var varNome = document.getElementById("nameCategory").value;
    var varCodice = document.getElementById("codeCategory").value;

    var objCategoria = {
        titolo: varNome,
        codice_categoria: varCodice
    };

    console.log(objCategoria);
    //console.log(JSON.stringify(objProdotto));


    $.ajax(
        {
            url: "http://localhost:8082/categoria/inserisciCategoria",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(objCategoria),
            dataType: "json",
            success: function(risultato){
                alert("Inserimento effettuato con successo!")
                // aggiornaElenco();
            },
            error: function(errore){
                alert("Errore di esecuzione")
                console.log(errore);
            }
        }
    )
}